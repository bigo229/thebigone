import sys
from urllib.parse import parse_qsl

class Params:
    def __init__(self, paramstring):
        self.params = {}
        if paramstring:
            # Cleans up system argument formats passed by addon.py
            if isinstance(paramstring, list):
                paramstring = paramstring[0] if len(paramstring) > 0 else ""
            
            if paramstring.startswith('?'):
                paramstring = paramstring[1:]
                
            # Cleanly converts url parameters into a Python dictionary
            self.params = dict(parse_qsl(paramstring))

    def get_params(self):
        return self.params

    def get_mode(self):
        mode = self.params.get('mode', None)
        return int(mode) if mode and mode.isdigit() else None

    def get_name(self):
        return self.params.get('name', '')

    def get_name2(self):
        return self.params.get('name2', '')

    def get_version(self):
        return self.params.get('version', '')

    def get_url(self):
        return self.params.get('url', '')

    def get_icon(self):
        return self.params.get('icon', '')

    def get_description(self):
        return self.params.get('description', '')

