import sys

from resources.lib.modules.plugin import router

if __name__ == '__main__':
    # Safely check if a query string exists in sys.argv[2]
    # If it exists, strip the leading '?' and pass it to the router
    # If it doesn't exist, pass an empty string to load the main menu
    query_string = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    
    router(query_string)

