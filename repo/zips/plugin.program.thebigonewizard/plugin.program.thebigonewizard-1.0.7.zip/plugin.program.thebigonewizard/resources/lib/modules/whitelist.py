import json
import sqlite3
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import re
import os
from itertools import count
from xml.etree import ElementTree as ET
from zipfile import ZipFile
from uservar import excludes
from .addonvar import addon_id, addon_name, addon_icon, textures_db, addons_db, db_path, installed_date, packages

translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addoninfo  = addon.getAddonInfo
addon_data  = translatePath(addon.getAddonInfo('profile'))
addons_path = translatePath(translatePath('special://home/addons'))
file_path = addon_data + 'whitelist.json'
dialog = xbmcgui.Dialog()

EXCLUDES_BASIC = excludes + [addon_id, textures_db, 'kodi.log', 'Addons33.db', 'packages', 'backups']
EXCLUDES_FRESH = [addon_id, textures_db, 'Addons33.db', 'kodi.log', 'plugin.program.theredwizard', 'repository.redwizard']

def strip_kodi_colors(text):
    if not text:
        return text
    return re.sub(r'\[\/?color[^\]]*\]', '', text, flags=re.IGNORECASE).strip()

def addon_xml_path(addon_folder):
    return os.path.join(addons_path, addon_folder, 'addon.xml')

def name_from_addon_xml(addon_folder):
    xml_path = addon_xml_path(addon_folder)
    if not xbmcvfs.exists(xml_path):
        return None
    try:
        with open(xml_path, 'r', encoding='utf-8', errors='ignore') as xml_file:
            text = xml_file.read(8192)
        match = re.search(r'<addon[^>]*\bname=["\']([^"\']+)["\']', text, re.IGNORECASE)
        if match:
            return strip_kodi_colors(match.group(1))
    except Exception:
        pass
    return None

def get_addon_name(addon_folder):
    try:
        return strip_kodi_colors(xbmcaddon.Addon(addon_folder).getAddonInfo('name'))
    except Exception:
        pass
    try:
        query = json.dumps({
            'jsonrpc': '2.0',
            'id': 1,
            'method': 'Addons.GetAddonDetails',
            'params': {'addonid': addon_folder, 'properties': ['name']}
        })
        name = json.loads(xbmc.executeJSONRPC(query)).get('result', {}).get('addon', {}).get('name')
        if name:
            return strip_kodi_colors(name)
    except Exception:
        pass
    xml_name = name_from_addon_xml(addon_folder)
    if xml_name:
        return xml_name
    return addon_folder

def add_whitelist():
    dirs, files = xbmcvfs.listdir(addons_path)
    dirs.sort()
    for x in ['packages', 'temp']:
        if x in dirs:
            dirs.remove(x)
    current_whitelist = []
    if xbmcvfs.exists(file_path):
        with open(file_path, 'r') as wl:
            current_whitelist = json.load(wl)['whitelist']
    xbmc.log('dirs = ' + str(dirs), xbmc.LOGINFO)
    names = []
    available = []
    for x in list(current_whitelist):
        if x not in dirs:
            current_whitelist.remove(x)
        else:
            dirs.remove(x)
    for foldername in dirs:
        if not xbmcvfs.exists(addon_xml_path(foldername)):
            continue
        available.append(foldername)
        names.append(get_addon_name(foldername))
    dirs = available
    if not names:
        xbmcgui.Dialog().notification(addon_name, 'No items available to add!', addon_icon, 3000)
        quit()
    ret = xbmcgui.Dialog().multiselect('Select Items to Add to Your Whitelist', names, preselect=[])
    xbmc.log('ret = ' + str(ret), xbmc.LOGINFO)
    if ret is None or not ret:
        return None
    whitelist = []
    for x in range(len(dirs)):
        if x in ret:
            whitelist.append(dirs[x])
    xbmc.log('whitelist = ' + str(whitelist), xbmc.LOGINFO)
    if not xbmcvfs.exists(addon_data):
        xbmcvfs.mkdir(addon_data)
    new_list = current_whitelist + whitelist
    with open(file_path, 'w') as whitelist_file:
        json.dump({'whitelist': new_list}, whitelist_file, indent = 4)
        xbmcgui.Dialog().notification(addon_name, '[COLOR gold]Whitelist Updated![/COLOR]', addon_icon, 3000)

def remove_whitelist():
    dirs, files = xbmcvfs.listdir(addons_path)
    dirs.sort()
    for y in ['packages', 'temp']:
        if y in dirs:
            dirs.remove(y)
    current_whitelist = []
    if xbmcvfs.exists(file_path):
        with open(file_path, 'r') as wl:
            current_whitelist = json.load(wl)['whitelist']
    names = []
    for y in list(current_whitelist):
        if y not in dirs:
            current_whitelist.remove(y)
        else:
            names.append(get_addon_name(y))
    if not names:
        xbmcgui.Dialog().notification(addon_name, '[COLOR gold]No items available to remove![/COLOR]', addon_icon, 3000)
        try:
            os.unlink(os.path.join(file_path))
        except Exception as e:
            xbmc.log('Failed to delete %s. Reason: %s' % (os.path.join(file_path), e), xbmc.LOGINFO)
        quit()
    ret = xbmcgui.Dialog().multiselect('Select Items to Remove From Your Whitelist', names, preselect=[])
    xbmc.log('ret = ' + str(ret), xbmc.LOGINFO)
    if ret is None or not ret:
        return None
    whitelist = []
    for x in range(len(current_whitelist)):
        if x in ret:
            whitelist.append(current_whitelist[x])
    xbmc.log('whitelist = ' + str(whitelist), xbmc.LOGINFO)
    for x in whitelist:
        current_whitelist.remove(x)
    if not current_whitelist:
        try:
            os.unlink(os.path.join(file_path))
        except Exception as e:
            xbmc.log('Failed to delete %s. Reason: %s' % (os.path.join(file_path), e), xbmc.LOGINFO)
        xbmcgui.Dialog().notification(addon_name, '[COLOR gold]Whitelist Updated![/COLOR]', addon_icon, 3000)
    else:
        with open(file_path, 'w') as whitelist_file:
            json.dump({'whitelist': current_whitelist}, whitelist_file, indent = 4)
            xbmcgui.Dialog().notification(addon_name, '[COLOR gold]Whitelist Updated![/COLOR]', addon_icon, 3000)
            
'''def view_whitelist():
    if xbmcvfs.exists(file_path):
        with open(file_path, 'r') as wl:
            current_whitelist = json.load(wl)['whitelist']
            whitelist = []
            key = None
            for key in current_whitelist:
                name = xbmcaddon.Addon(key).getAddonInfo('name')
                whitelist.append(name)
                a = str(whitelist)
                b = a.replace("[", "\n       >>>  ", 1)
                #button_number_count = 2;
                #counter = count(button_number_count)
                #c = re.sub(r',', lambda x: x.group(0) + str(next(counter)), b)
                c = "".join(re.split("\[|\]", b)[::2])
                replacements = {"]": "", "'": "", ",": "\n       >>> "}
                for old, new in replacements.items():
                    c = c.replace(old, new)
                    cleanlist = c
            return cleanlist
your_whitelist = view_whitelist()'''
        
def read_whitelist(_excludes):
    if xbmcvfs.exists(file_path):
        with open(file_path, 'r') as wl:
            whitelist  = json.loads(wl.read())['whitelist']
        for x in whitelist:
            if not x in _excludes:
                _excludes.append(x)
        return _excludes
    else:
        return _excludes
EXCLUDES_INSTALL = read_whitelist(EXCLUDES_BASIC)

_ADDONS_DB_NAME = re.compile(r'(?:^|[/\\])Addons(\d+)\.db$', re.I)
_SKIP_IMPORT = ('xbmc.', 'kodi.')


def whitelist_ids():
    if not xbmcvfs.exists(file_path):
        return []
    try:
        with open(file_path, 'r') as wl:
            ids = json.load(wl).get('whitelist') or []
        return [x for x in ids if x]
    except Exception:
        return []


def _generation_from_name(name):
    match = _ADDONS_DB_NAME.search(str(name).replace('\\', '/'))
    return int(match.group(1)) if match else None


def _disk_addons_db():
    if not os.path.isdir(db_path):
        return None, None
    found = []
    for name in os.listdir(db_path):
        gen = _generation_from_name(name)
        if gen is not None:
            found.append((os.path.join(db_path, name), gen))
    if not found:
        return None, None
    for path, gen in found:
        if os.path.normcase(path) == os.path.normcase(addons_db):
            return path, gen
    found.sort(key=lambda item: item[1], reverse=True)
    return found[0]


def _zip_addons_member(zf):
    found = []
    for name in zf.namelist():
        gen = _generation_from_name(name)
        if gen is not None:
            found.append((name, gen))
    if not found:
        return None, None
    database = [item for item in found if '/Database/' in item[0].replace('\\', '/') or item[0].replace('\\', '/').startswith('Database/')]
    pool = database or found
    pool.sort(key=lambda item: item[1], reverse=True)
    return pool[0]


def _zip_folder_ids(zf):
    ids = set()
    for name in zf.namelist():
        match = re.search(r'(?:^|[/\\])addons[/\\]([^/\\]+)[/\\]addon\.xml$', name, re.I)
        if match:
            ids.add(match.group(1))
    return ids


def _skip_import(addon_id_value):
    if not addon_id_value:
        return True
    lower = addon_id_value.lower()
    return lower.startswith(_SKIP_IMPORT)


def _addon_folder_exists(addon_id_value):
    return xbmcvfs.exists(addon_xml_path(addon_id_value))


def _installed_ids(conn):
    try:
        return {row[0] for row in conn.execute('SELECT addonID FROM installed') if row[0]}
    except Exception:
        return set()


def _origin_of(conn, addon_id_value):
    try:
        row = conn.execute('SELECT origin FROM installed WHERE addonID = ?', (addon_id_value,)).fetchone()
        origin = (row[0] if row else '') or ''
        if origin.startswith('repository.') or _addon_folder_exists(origin):
            return origin
    except Exception:
        pass
    return ''


def _repos_of(conn, addon_id_value):
    try:
        rows = conn.execute(
            'SELECT r.addonID FROM addonlinkrepo l '
            'JOIN addons a ON a.id = l.idAddon '
            'JOIN repo r ON r.id = l.idRepo '
            'WHERE a.addonID = ?',
            (addon_id_value,)
        ).fetchall()
        return [row[0] for row in rows if row[0]]
    except Exception:
        return []


def _requires(addon_id_value):
    xml_path = addon_xml_path(addon_id_value)
    if not xbmcvfs.exists(xml_path):
        return []
    try:
        root = ET.parse(xml_path).getroot()
    except Exception:
        return []
    deps = []
    for item in root.findall('./requires/import'):
        dep = item.get('addon') or ''
        if _skip_import(dep):
            continue
        optional = str(item.get('optional') or '').strip().lower() in ('true', 'yes', '1')
        deps.append((dep, optional))
    return deps


def _walk_whitelist_closure(conn, seeds, present):
    queue = list(seeds)
    seen = set()
    while queue:
        current = queue.pop()
        if not current or current in seen or _skip_import(current):
            continue
        if current not in present and not _addon_folder_exists(current):
            continue
        seen.add(current)
        origin = _origin_of(conn, current)
        if origin:
            queue.append(origin)
        for repo_id in _repos_of(conn, current):
            queue.append(repo_id)
        for dep, _optional in _requires(current):
            if dep not in present and not _addon_folder_exists(dep):
                continue
            queue.append(dep)
    return seen


def _snapshot_rows(conn, keep_ids):
    snapshot = {'installed': [], 'addons': [], 'repo': [], 'package': [], 'links': []}
    if not keep_ids:
        return snapshot
    marks = ','.join('?' * len(keep_ids))
    ids = list(keep_ids)
    snapshot['installed'] = [
        dict(zip(
            ('addonID', 'enabled', 'installDate', 'lastUpdated', 'lastUsed', 'origin', 'disabledReason'),
            row
        ))
        for row in conn.execute(
            'SELECT addonID, enabled, installDate, lastUpdated, lastUsed, origin, disabledReason '
            'FROM installed WHERE addonID IN (%s)' % marks, ids
        )
    ]
    snapshot['addons'] = [
        dict(zip(
            ('metadata', 'addonID', 'version', 'name', 'summary', 'news', 'description'),
            row
        ))
        for row in conn.execute(
            'SELECT metadata, addonID, version, name, summary, news, description '
            'FROM addons WHERE addonID IN (%s)' % marks, ids
        )
    ]
    snapshot['repo'] = [
        dict(zip(('addonID', 'checksum', 'lastcheck', 'version', 'nextcheck'), row))
        for row in conn.execute(
            'SELECT addonID, checksum, lastcheck, version, nextcheck FROM repo WHERE addonID IN (%s)' % marks, ids
        )
    ]
    snapshot['package'] = [
        dict(zip(('addonID', 'filename', 'hash'), row))
        for row in conn.execute(
            'SELECT addonID, filename, hash FROM package WHERE addonID IN (%s)' % marks, ids
        )
    ]
    snapshot['links'] = [
        {'addonID': row[0], 'repoID': row[1]}
        for row in conn.execute(
            'SELECT a.addonID, r.addonID FROM addonlinkrepo l '
            'JOIN addons a ON a.id = l.idAddon '
            'JOIN repo r ON r.id = l.idRepo '
            'WHERE a.addonID IN (%s)' % marks, ids
        )
    ]
    return snapshot


def prepare_whitelist_install(build_zip):
    """Same-generation keep-set and rows. Generation jump keeps today's whitelist folders only."""
    plan = {'extra_excludes': [], 'wipe_ids': [], 'snapshot': None, 'enable_ids': []}
    seeds = whitelist_ids()
    if not seeds or not build_zip or not os.path.exists(build_zip):
        return plan
    disk_path, disk_gen = _disk_addons_db()
    try:
        with ZipFile(build_zip, 'r') as zf:
            zip_member, zip_gen = _zip_addons_member(zf)
            zip_ids = _zip_folder_ids(zf)
    except Exception as e:
        xbmc.log('Whitelist: could not read build zip Addons database - %s' % e, xbmc.LOGINFO)
        return plan
    if disk_path is None or disk_gen is None or zip_gen is None or disk_gen != zip_gen:
        xbmc.log('Whitelist: Addons database generation differs or is missing; keeping listed add-ons only', xbmc.LOGINFO)
        return plan
    try:
        conn = sqlite3.connect(disk_path)
    except Exception as e:
        xbmc.log('Whitelist: could not open disk Addons database - %s' % e, xbmc.LOGINFO)
        return plan
    try:
        present = _installed_ids(conn)
        closure = _walk_whitelist_closure(conn, seeds, present)
        keep_ids = {addon for addon in closure if addon not in zip_ids}
        protected = {addon_id, textures_db, 'kodi.log', 'Addons33.db', 'packages', 'backups'}
        plan['enable_ids'] = sorted(closure)
        plan['extra_excludes'] = [addon for addon in sorted(keep_ids) if addon not in EXCLUDES_INSTALL]
        plan['wipe_ids'] = [addon for addon in seeds if addon in zip_ids and addon not in protected]
        if keep_ids:
            plan['snapshot'] = _snapshot_rows(conn, keep_ids)
        xbmc.log('Whitelist: same generation %s, keep %s, wipe %s, enable %s' % (disk_gen, sorted(keep_ids), plan['wipe_ids'], plan['enable_ids']), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('Whitelist: failed to prepare keep-set - %s' % e, xbmc.LOGINFO)
        plan = {'extra_excludes': [], 'wipe_ids': [], 'snapshot': None, 'enable_ids': []}
    finally:
        conn.close()
    return plan


def apply_whitelist_install(plan):
    if not plan:
        return
    enable_ids = plan.get('enable_ids') or []
    snapshot = plan.get('snapshot')
    if not enable_ids and not snapshot:
        return
    if not os.path.exists(addons_db):
        return
    try:
        conn = sqlite3.connect(addons_db)
        cur = conn.cursor()
        if snapshot:
            for row in snapshot.get('repo') or []:
                found = cur.execute('SELECT id FROM repo WHERE addonID = ?', (row['addonID'],)).fetchone()
                if found:
                    continue
                cur.execute(
                    'INSERT INTO repo (addonID, checksum, lastcheck, version, nextcheck) VALUES (?, ?, ?, ?, ?)',
                    (row['addonID'], row.get('checksum') or '', row.get('lastcheck') or '', row.get('version') or '', row.get('nextcheck') or '')
                )
            for row in snapshot.get('addons') or []:
                found = cur.execute('SELECT id FROM addons WHERE addonID = ?', (row['addonID'],)).fetchone()
                if found:
                    continue
                cur.execute(
                    'INSERT INTO addons (metadata, addonID, version, name, summary, news, description) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    (row.get('metadata'), row['addonID'], row.get('version') or '', row.get('name') or '', row.get('summary') or '', row.get('news') or '', row.get('description') or '')
                )
            for row in snapshot.get('installed') or []:
                found = cur.execute('SELECT id FROM installed WHERE addonID = ?', (row['addonID'],)).fetchone()
                if not found:
                    cur.execute(
                        'INSERT INTO installed (addonID, enabled, installDate, lastUpdated, lastUsed, origin, disabledReason) VALUES (?, ?, ?, ?, ?, ?, ?)',
                        (row['addonID'], 1, row.get('installDate') or installed_date, row.get('lastUpdated') or '', row.get('lastUsed') or '', row.get('origin') or '', 0)
                    )
            for row in snapshot.get('package') or []:
                found = cur.execute(
                    'SELECT id FROM package WHERE addonID = ? AND filename = ?',
                    (row['addonID'], row.get('filename') or '')
                ).fetchone()
                if found:
                    continue
                cur.execute(
                    'INSERT INTO package (addonID, filename, hash) VALUES (?, ?, ?)',
                    (row['addonID'], row.get('filename') or '', row.get('hash') or '')
                )
            for link in snapshot.get('links') or []:
                addon_row = cur.execute('SELECT id FROM addons WHERE addonID = ?', (link['addonID'],)).fetchone()
                repo_row = cur.execute('SELECT id FROM repo WHERE addonID = ?', (link['repoID'],)).fetchone()
                if not addon_row or not repo_row:
                    continue
                found = cur.execute(
                    'SELECT idRepo FROM addonlinkrepo WHERE idRepo = ? AND idAddon = ?',
                    (repo_row[0], addon_row[0])
                ).fetchone()
                if found:
                    continue
                cur.execute('INSERT INTO addonlinkrepo (idRepo, idAddon) VALUES (?, ?)', (repo_row[0], addon_row[0]))
        for addon in enable_ids:
            found = cur.execute('SELECT id FROM installed WHERE addonID = ?', (addon,)).fetchone()
            if found:
                cur.execute('UPDATE installed SET enabled = ? WHERE addonID = ?', (1, addon))
            elif _addon_folder_exists(addon):
                cur.execute(
                    'INSERT INTO installed (addonID, enabled, installDate, lastUpdated, lastUsed, origin, disabledReason) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    (addon, 1, installed_date, '', '', '', 0)
                )
        conn.commit()
    except Exception as e:
        xbmc.log('Whitelist: failed to write kept Addons rows - %s' % e, xbmc.LOGINFO)
    finally:
        try:
            conn.close()
        except Exception:
            pass
