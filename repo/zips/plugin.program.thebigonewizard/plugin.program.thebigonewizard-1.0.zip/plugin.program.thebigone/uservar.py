import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/bigo229/thebigone/master/builds/tbo-builds.xml'

'''#####-----Videos File-----#####'''
videos_url = ''

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/bigo229/thebigone/master/builds/tbo-notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'https://raw.githubusercontent.com/bigo229/thebigone/master/builds/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
