import xbmc
import xbmcgui
import xbmcaddon
import re
import urllib.error
from ..modules.parser import get_page
from ..modules import _service
from uservar import notify_url, changelog_dir
from .addonvar import setting

def get_notify() -> list:
    response = get_page(notify_url)
    try:
        split_response = response.split('|||')
        notify_version = int(split_response[0])
        message = split_response[1]
    except:
        notify_version = 0
        message = 'Improper Notifications format. Please check the Notifications text.'
    return [notify_version, message]

def get_changelog():
    # Forces the wizard to look directly for your 'changelog.txt' file
    changelog = '%schangelog.txt' % changelog_dir
    
    try:
        message = get_page(changelog)
    except urllib.error.HTTPError as e:
        # Prevents Kodi from crashing if the web file is missing or 404s
        message = "[COLOR red]Notice:[/COLOR] Changelog file not found on server."
    except Exception as e:
        # Catches other connection errors (e.g. user has no internet)
        message = "[COLOR red]Notice:[/COLOR] Connection error. Could not retrieve changelog."
        
    return message

def notification(message: str) -> None:  
    class Notify(xbmcgui.WindowXMLDialog):
        KEY_NAV_BACK = 92
        TEXTBOX = 300
        CLOSEBUTTON = 302
        
        def onInit(self):
            self.getControl(self.TEXTBOX).setText(message)
            
        def onAction(self, action):
            if action.getId() == self.KEY_NAV_BACK:
                self.Close()
    
        def onClick(self, controlId):
            if controlId == self.CLOSEBUTTON:
                self.Close()

        def Close(self):
            self.close()
            
    d = Notify('notify.xml', xbmcaddon.Addon().getAddonInfo('path'), 'Default', '720p')
    d.doModal()
    del d

def notification_clog(message: str) -> None:  
    class Notify(xbmcgui.WindowXMLDialog):
        KEY_NAV_BACK = 92
        TEXTBOX = 300
        CLOSEBUTTON = 302
        
        def onInit(self):
            self.getControl(self.TEXTBOX).setText(message)
            
        def onAction(self, action):
            if action.getId() == self.KEY_NAV_BACK:
                self.close()
                _service.Startup().check_updates()
    
        def onClick(self, controlId):
            if controlId == self.CLOSEBUTTON:
                self.close()
                _service.Startup().check_updates()

        def Close(self):
            self.close()
            _service.Startup().check_updates()
    
    d = Notify('notify.xml', xbmcaddon.Addon().getAddonInfo('path'), 'Default', '720p')
    d.doModal()
    del d
